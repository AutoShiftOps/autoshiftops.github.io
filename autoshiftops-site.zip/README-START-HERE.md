# AutoShiftOps — new site, ready to drop in

## What this is

A complete Jekyll site: layouts, includes, styling, and pages. It replaces
your current theme entirely rather than patching it, since I could only see
your site's rendered HTML, not your actual `_layouts`/`_includes` source.

## Before you push this live

1. **Move your existing `_posts/` folder over.** This package includes one
   template post (`_posts/2026-07-17-post-title-goes-here.md`) so you can see
   the expected front matter format — delete it once you've moved your real
   61 posts in. Your existing post *content* doesn't need to change, only
   double-check each has `categories`/`tags` that match the pillar keyword
   lists in `BLOGGING-WORKFLOW.md`, so they show up under the right filter
   on `/blog/`.

2. **Update placeholder links** in `_config.yml`:
   - `social.linkedin` — currently a placeholder, put your real profile URL in.
   - Double check `social.github_org`, `social.youtube`, `social.querytuner`
     are correct (they should already be right).

3. **Add a photo** (optional). The hero is currently text-only by design —
   if you want a headshot, add it to `assets/images/` and I can wire it into
   the hero layout.

4. **Newsletter/affiliate content removed on purpose.** Your old homepage had
   a "Join Newsletter" CTA and an affiliate marketing post featured — both
   read as monetization-first, which works against a "hire me" positioning.
   The newsletter subscribe block isn't in this version. If you still want a
   newsletter somewhere on the site, say so and we'll place it deliberately
   rather than as the primary CTA.

5. **Test locally before pushing** (see `BLOGGING-WORKFLOW.md` section 4) —
   `bundle exec jekyll serve` — to catch anything Jekyll-specific that
   doesn't match your GitHub Pages plugin whitelist.

## File map

```
_config.yml              site settings, social links
_layouts/default.html    shared page shell (nav + footer)
_layouts/post.html       blog post layout
_includes/nav.html       site navigation
_includes/footer.html    site footer
assets/css/main.css      all styling
index.html               homepage
projects.md              full project detail page
about.md                 about page
contact.md               contact page
blog.html                blog listing with pillar filter
_posts/                  your blog posts go here (see BLOGGING-WORKFLOW.md)
BLOGGING-WORKFLOW.md      how to write & publish new posts going forward
```

## What's NOT included

- Your 61 existing blog posts — I don't have access to your repo, so I
  couldn't pull the actual Markdown files. Move them into `_posts/` as-is;
  the new post layout will style them automatically.
- A real photo — text-only hero for now, easy to add.
- Jekyll tag/category pages beyond the JS-based pillar filter on `/blog/` —
  this was the pragmatic choice so none of your 61 existing posts need their
  front matter rewritten immediately. If you'd rather have "real" Jekyll
  category pages later, that's a small follow-up.
